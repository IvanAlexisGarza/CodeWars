# AStar

AStar example with community contributions.

https://codingtrain.github.io/AStar/

Original source code:
- https://github.com/CodingTrain/Rainbow-Code/tree/master/challenges/CC_51_astar

Video tutorial:
- [Part 1](https://www.youtube.com/watch?v=aKYlikFAV4k)
- [Part 2](https://www.youtube.com/watch?v=EaZxUCWAjb0)
- [Part 3](https://www.youtube.com/watch?v=aKYlikFAV4k)
